# Andam push alerts

Andam shows warnings when you open it. This add-on sends a **message to your phone** even when the app is closed,
when the weather, an earthquake or a storm near your places reaches **Warning** or **Danger**.

- It checks every hour (GitHub may be 10 to 30 minutes late at busy times).
- It uses the same free services and the same rules as the app. It is a guide, **not** an official warning.
  Always follow PAGASA, PHIVOLCS and your LGU.
- It is free. It uses the free **ntfy** app on your phone and GitHub, which you already use to host Andam.
- It needs internet on your phone to receive the message. If the signal is down, you will not get it.

## Set it up (about 15 minutes, once)

### 1. Put ntfy on your phone
1. Install **ntfy** (Android: Play Store or F-Droid. iPhone: App Store).
2. Open it, tap **+**, and type a topic name. Use something long that nobody can guess. Here is one made for you:

   `andam-c8pdhljor9z07f`

   (Anyone who knows the topic name can read the messages, so keep it private. You can make up your own.)
3. Tap **Subscribe**. Allow notifications when your phone asks.
4. Give the same topic name to your parents and sisters if they want the messages too. Each of them installs ntfy and subscribes to the same name.

### 2. Add two files to your Andam repository on GitHub
Use the same repository that hosts Andam. Do these steps twice, once for each file.

1. Open the repository on github.com. Tap **Add file**, then **Create new file**.
2. In the name box, type the name below **exactly**. Typing a `/` makes a folder.
   - First file: `.github/workflows/andam-alerts.yml`
   - Second file: `alerts/check_alerts.py`
3. Open the matching file from this package, copy everything, and paste it into the big box on GitHub.
4. Tap **Commit changes**, then **Commit changes** again.

### 3. Add your secrets
1. In the repository tap **Settings**, then **Secrets and variables**, then **Actions**.
2. Tap **New repository secret** and add:
   - Name `NTFY_TOPIC`, value: your topic name from step 1.
   - Name `PLACES`, value: one place per line, like this (name, latitude, longitude):
     ```
     Isabel, Leyte, 10.93, 124.43
     Tacloban City, 11.244, 125.0
     ```
     In Andam, the Family tab has "Use my location" for your places. Those numbers work here too.
     If you skip `PLACES`, it checks Isabel, Leyte only.

Secrets stay hidden. Nobody who sees the repository can read them.

### 4. Test it
1. Tap the **Actions** tab. If GitHub asks, tap **I understand my workflows, enable them**.
2. Tap **Andam alerts** on the left, then **Run workflow**.
3. Tick **Send a test message to my phone**, then tap the green **Run workflow** button.
4. In about a minute your phone should show "Andam test". If not, see "If it does not work" below.

That is all. It now checks every hour by itself.

## What you will get
- A message only for **Warning** and **Danger** (heavy rain, strong wind, extreme heat, big nearby earthquakes, a storm within 500 km, a volcano within 100 km).
- The same warning is not repeated every hour. A new message comes if it gets worse or a new event starts.
- On Sundays, one quiet message: "Andam alerts are running". If it stops coming, the checker has been switched off (see below).

## Optional settings
Add these under **Settings, Secrets and variables, Actions, Variables tab, New repository variable**:

| Name | Value | What it does |
| --- | --- | --- |
| `MIN_LEVEL` | `2` | Also send **Watch** level messages (more messages). Default is `3`. |
| `ALERT_LANGUAGE` | `ceb` | Messages in Bisaya. |
| `HEARTBEAT` | `off` | No Sunday "still running" message. |

## If it does not work
- **No test message:** check the topic name is exactly the same in the ntfy app and in the `NTFY_TOPIC` secret. Look at the run in the Actions tab: a red mark means open it and read the last lines.
- **Messages stopped:** GitHub switches off scheduled jobs in a repository that has had no changes for 60 days. In the **Actions** tab tap **Andam alerts**, then **Enable workflow**. Making any small change to the repository (for example, updating Andam) also keeps it awake.
- **Too many messages:** keep `MIN_LEVEL` at 3, or remove a place from `PLACES`.
- ntfy's free server is public. Do not put private information in the place names. Nothing else is sent: only the warning text and place name.

## Be honest about the limits
This depends on the internet, GitHub, ntfy and free weather services all working. In a typhoon or after a big earthquake, any of them can fail.
It does not replace your radio, PAGASA bulletins, your barangay's alarm, or your own eyes on the river and the sky.
