#!/usr/bin/env python3
"""Andam push alerts.

Runs on GitHub every hour (see .github/workflows/andam-alerts.yml). It checks the same free services as the
Andam app (Open-Meteo weather, USGS earthquakes, NASA EONET storms and events) for each place you list, and
sends a message to your phone through the free ntfy app when something reaches Warning or Danger.

This is a guide, not an official warning. Follow PAGASA, PHIVOLCS and your LGU.
Only the Python standard library is used.
"""
import calendar
import datetime as dt
import json
import math
import os
import sys
import time
import urllib.parse
import urllib.request

UA = "andam-alerts/1.0 (family readiness app)"
STATE_FILE = os.environ.get("STATE_FILE", "alerts-state.json")
DEFAULT_PLACES = "Isabel, Leyte, 10.93, 124.43"


# ---------------------------------------------------------------- small helpers
def get_json(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def post_json(url, obj, timeout=25):
    data = json.dumps(obj).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers={"User-Agent": UA, "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status


def hav(la1, lo1, la2, lo2):
    rad = math.radians
    a = math.sin(rad(la2 - la1) / 2) ** 2 + math.cos(rad(la1)) * math.cos(rad(la2)) * math.sin(rad(lo2 - lo1) / 2) ** 2
    return 6371 * 2 * math.asin(min(1.0, math.sqrt(a)))


def rnd(x):  # JavaScript Math.round (halves go up), so results match the app
    return int(math.floor(x + 0.5))


def r1(x):  # one decimal, shown without ".0" (same as the app)
    v = rnd(x * 10) / 10
    return int(v) if v == int(v) else v


def parse_places(text):
    """One place per line: Name, latitude, longitude  (a ; also separates places)."""
    out = []
    for line in (text or "").replace(";", "\n").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.rsplit(",", 2)]
        if len(parts) != 3:
            print("Skipping a line I could not read:", line)
            continue
        try:
            lat, lng = float(parts[1]), float(parts[2])
        except ValueError:
            print("Skipping a line with bad numbers:", line)
            continue
        if not (-90 <= lat <= 90 and -180 <= lng <= 180):
            print("Skipping a place outside the map:", line)
            continue
        out.append({"name": parts[0] or "Place", "lat": lat, "lng": lng})
    return out


# ---------------------------------------------------------------- the checks (same thresholds as the app)
def weather(lat, lng, now):
    j = get_json("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
                 "&hourly=precipitation,wind_gusts_10m,apparent_temperature&forecast_days=3&timezone=auto&wind_speed_unit=kmh" % (lat, lng))
    h = j["hourly"]
    off = j.get("utc_offset_seconds") or 0
    idx = []
    for i, s in enumerate(h["time"]):
        t = calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M")) - off
        if now - 1800 <= t <= now + 48 * 3600:
            idx.append((i, t))
    out = []
    if not idx:
        return out
    in_h = lambda t: max(0, rnd((t - now) / 3600))
    num = lambda arr, i: (arr[i] if arr[i] is not None else 0)
    max1, max1t, best24, best24t = 0, now, 0, now
    for k, (i, t) in enumerate(idx):
        p = num(h["precipitation"], i)
        if p > max1:
            max1, max1t = p, t
        s = sum(num(h["precipitation"], idx[m][0]) for m in range(k, min(len(idx), k + 24)))
        if s > best24:
            best24, best24t = s, t
    rl = 4 if (max1 >= 30 or best24 >= 150) else 3 if (max1 >= 15 or best24 >= 100) else 2 if (max1 >= 7.5 or best24 >= 50) else 1 if best24 >= 25 else 0
    day = lambda t: time.strftime("%Y-%m-%d", time.gmtime(t))
    if rl:
        t0 = max1t if max1 >= 7.5 else best24t
        out.append({"k": "rain", "lvl": rl, "id": "rain-" + day(t0), "a": {"h1": r1(max1), "d": rnd(best24), "in": in_h(t0)}})
    g, gt = 0, now
    for i, t in idx:
        v = num(h["wind_gusts_10m"], i)
        if v > g:
            g, gt = v, t
    wl = 4 if g >= 100 else 3 if g >= 75 else 2 if g >= 55 else 0
    if wl:
        out.append({"k": "wind", "lvl": wl, "id": "wind-" + day(gt), "a": {"g": rnd(g), "in": in_h(gt)}})
    ap, apt = -99, now
    for i, t in idx:
        v = h["apparent_temperature"][i]
        if v is not None and v > ap:
            ap, apt = v, t
    hl = 4 if ap >= 52 else 3 if ap >= 42 else 1 if ap >= 38 else 0
    if hl:
        out.append({"k": "heat", "lvl": hl, "id": "heat-" + day(apt), "a": {"t": rnd(ap), "in": in_h(apt)}})
    return out


def quakes(lat, lng, now):
    since = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(now - 48 * 3600))
    j = get_json("https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&latitude=%s&longitude=%s"
                 "&maxradiuskm=400&minmagnitude=4&orderby=time&limit=50&starttime=%s" % (lat, lng, since))
    lst = []
    for f in j.get("features") or []:
        c = (f.get("geometry") or {}).get("coordinates") or []
        p = f.get("properties") or {}
        if len(c) < 2:
            continue
        d, m = hav(lat, lng, c[1], c[0]), float(p.get("mag") or 0)
        lvl = 4 if ((m >= 7 and d <= 400) or (m >= 6 and d <= 150)) else 3 if (m >= 6 or (m >= 5 and d <= 100)) else 2 if (m >= 5 or (m >= 4.5 and d <= 150)) else 1 if d <= 200 else 0
        if p.get("tsunami") == 1:
            lvl = max(lvl, 3)
        if lvl:
            ago = max(0, rnd((now * 1000 - float(p.get("time") or 0)) / 60000))
            lst.append({"k": "quake", "lvl": lvl, "id": "quake-" + str(f.get("id") or p.get("time")), "a": {"m": r1(m), "d": rnd(d), "ago": ago, "ts": 1 if p.get("tsunami") == 1 else 0}})
    lst.sort(key=lambda x: (-x["lvl"], -x["a"]["m"]))
    return lst[:3]


def events(lat, lng, now):
    B = 10
    j = get_json("https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=100&bbox=%s,%s,%s,%s" % (lng - B, lat + B, lng + B, lat - B))
    out = []
    for e in j.get("events") or []:
        cat = ((e.get("categories") or [{}])[0] or {}).get("id")
        geo = e.get("geometry") or []
        g = geo[-1] if geo else None
        if not g or not g.get("coordinates"):
            continue
        c = g["coordinates"]
        while isinstance(c[0], list):
            c = c[0]
        d = hav(lat, lng, c[1], c[0])
        try:
            when = calendar.timegm(time.strptime(g["date"][:19], "%Y-%m-%dT%H:%M:%S"))
        except Exception:
            continue
        age = (now - when) / 86400
        lvl, kind = 0, ""
        if cat == "severeStorms" and age <= 3:
            kind, lvl = "storm", 3 if d <= 500 else 2 if d <= 1000 else 0
        elif cat == "volcanoes" and age <= 30:
            kind, lvl = "volcano", 3 if d <= 100 else 2 if d <= 300 else 0
        elif cat == "floods" and age <= 5:
            kind, lvl = "flood", 2 if d <= 200 else 0
        elif cat == "landslides" and age <= 5:
            kind, lvl = "landslide", 2 if d <= 100 else 0
        elif cat == "wildfires" and age <= 3:
            kind, lvl = "fire", 2 if d <= 50 else 0
        if lvl:
            out.append({"k": kind, "lvl": lvl, "id": kind + "-" + str(e.get("id")), "a": {"n": str(e.get("title") or "")[:60], "d": rnd(d)}})
    out.sort(key=lambda x: (-x["lvl"], x["a"]["d"]))
    return out[:4]


def check(lat, lng, now=None):
    now = now if now is not None else time.time()
    items, failed = [], []
    for name, fn in (("weather", weather), ("earthquakes", quakes), ("storms and events", events)):
        try:
            items.extend(fn(lat, lng, now))
        except Exception as e:  # one service being down must not stop the others
            failed.append(name)
            print("  could not check %s: %s" % (name, e))
    items.sort(key=lambda x: -x["lvl"])
    return items, failed


# ---------------------------------------------------------------- the words (English and Bisaya, same as the app)
LEVELS = {"en": ["Clear", "Note", "Watch", "Warning", "Danger"], "ceb": ["Maayo", "Timan-i", "Bantayi", "Pasidaan", "Peligro"]}


def _in(n, ceb):
    return ("karon" if ceb else "now") if n <= 0 else ("sulod sa mga %d ka oras" % n if ceb else "in about %d h" % n)


def _ago(m, ceb):
    h = rnd(m / 60)
    if m < 90:
        return ("mga %d ka minuto ang milabay" % max(1, m)) if ceb else "%d min ago" % max(1, m)
    return ("mga %d ka oras ang milabay" % h) if ceb else "%d h ago" % h


def text(it, ceb=False):
    a, L, k = it["a"], it["lvl"], it["k"]
    T = (lambda en, cb: cb) if ceb else (lambda en, cb: en)
    if k == "rain":
        return (T(["Rain expected", "Rain expected", "Heavy rain expected", "Very heavy rain expected", "Extreme rain expected"][L],
                  ["Moulan", "Moulan", "Kusog nga ulan", "Hilabihan kakusog nga ulan", "Grabeng kakusog nga ulan"][L]),
                T("Up to %s mm in one hour and about %s mm in 24 hours, %s. %s" % (a["h1"], a["d"], _in(a["in"], 0),
                  "Floods and landslides are possible. Be ready to move to higher ground." if L >= 3 else "Streams and low roads may flood. Watch the river and slopes." if L == 2 else "Bring a raincoat."),
                  "Hangtud %s mm sa usa ka oras ug mga %s mm sulod sa 24 ka oras, %s. %s" % (a["h1"], a["d"], _in(a["in"], 1),
                  "Posibleng mobaha ug mag-guba ang bakilid. Andam nga mobalhin sa mas taas nga dapit." if L >= 3 else "Basin mobaha ang sapa ug ubos nga dalan. Bantayi ang suba ug bakilid." if L == 2 else "Magdala og kapote.")))
    if k == "wind":
        return (T(["", "", "Strong winds expected", "Very strong winds expected", "Destructive winds expected"][L],
                  ["", "", "Kusog nga hangin", "Hilabihan kakusog nga hangin", "Makaguba nga hangin"][L]),
                T("Gusts up to %s km/h, %s. Tie down loose roofing and objects. Stay indoors, away from windows." % (a["g"], _in(a["in"], 0)),
                  "Bugso sa hangin hangtud %s km/h, %s. Higpita ang luag nga yero ug butang. Pabilin sa sulod, layo sa bintana." % (a["g"], _in(a["in"], 1))))
    if k == "heat":
        return (T(["", "Very hot", "", "Heat danger", "Extreme heat danger"][L], ["", "Init kaayo", "", "Peligro sa kainit", "Grabeng peligro sa kainit"][L]),
                T("Feels like up to %s°C, %s. Drink water often, rest in the shade at midday, and check on children and the elderly.%s" % (a["t"], _in(a["in"], 0), " Heat stroke is possible." if L >= 3 else ""),
                  "Murag %s°C ang gibati, %s. Inom og tubig kanunay, pahulay sa landong sa udto, ug tan-awa ang bata ug tigulang.%s" % (a["t"], _in(a["in"], 1), " Posible ang heat stroke." if L >= 3 else "")))
    if k == "quake":
        return (T("Magnitude %s earthquake about %s km away" % (a["m"], a["d"]), "Linog nga magnitude %s mga %s km ang gilay-on" % (a["m"], a["d"])),
                T("%s. %s%sCheck PHIVOLCS for details. Magnitudes here come from USGS and can differ." % (_ago(a["ago"], 0),
                  "Expect aftershocks and check your home for damage. On the coast, if you felt long strong shaking, go uphill. " if L >= 3 else "Aftershocks are possible. ",
                  "A tsunami message was issued. " if a["ts"] else ""),
                  "%s. %s%sTan-awa ang PHIVOLCS alang sa detalye. Ang magnitude dinhi gikan sa USGS ug mahimong lahi." % (_ago(a["ago"], 1),
                  "Hulata ang mga aftershock ug susiha ang balay kung naay kadaot. Sa baybayon, kung nibati og taas ug kusog nga uyog, dangat sa taas nga dapit. " if L >= 3 else "Posible ang aftershock. ",
                  "Naay gipagawas nga pahibalo sa tsunami. " if a["ts"] else "")))
    if k == "storm":
        return (T("%s is about %s km away" % (a["n"], a["d"]), "Ang %s mga %s km ang gilay-on" % (a["n"], a["d"])),
                T("Follow PAGASA for its track and wind signals. " + ("Prepare water, charge phones, secure the house, and be ready to evacuate if told." if L >= 3 else "Keep your go-bag and phones ready."),
                  "Sunda ang PAGASA alang sa dagan ug signal sa hangin. " + ("Andama ang tubig, i-charge ang telepono, higpita ang balay, ug andam nga mo-evacuate kung gisugo." if L >= 3 else "Andama ang go-bag ug telepono.")))
    if k == "volcano":
        return (T("%s (volcano) is about %s km away" % (a["n"], a["d"]), "%s (bulkan) mga %s km ang gilay-on" % (a["n"], a["d"])),
                T("Follow PHIVOLCS for the alert level and the danger zone.", "Sunda ang PHIVOLCS alang sa alert level ug danger zone."))
    if k in ("flood", "landslide", "fire"):
        kind = {"flood": ("flood", "baha"), "landslide": ("landslide", "pagguba sa bakilid"), "fire": ("fire", "sunog")}[k]
        return (T("Reported %s: %s (about %s km away)" % (kind[0], a["n"], a["d"]), "Gitaho nga %s: %s (mga %s km ang gilay-on)" % (kind[1], a["n"], a["d"])),
                T("Check local news and your LGU before you travel.", "Susiha ang lokal nga balita ug LGU sa dili ka mobiya."))
    return (k, "")


# ---------------------------------------------------------------- remembering what was already sent
def load_state(path):
    try:
        with open(path, encoding="utf-8") as f:
            s = json.load(f)
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def save_state(path, s):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(s, f)


def notify(server, topic, title, message, level, tags):
    return post_json(server.rstrip("/") + "/", {"topic": topic, "title": title, "message": message,
                                                "priority": 5 if level >= 4 else 4 if level == 3 else 3, "tags": tags})


# ---------------------------------------------------------------- main
def run(env=None, now=None, send=None, checker=None):
    env = os.environ if env is None else env
    now = now if now is not None else time.time()
    send = send or notify
    checker = checker or check
    topic = (env.get("NTFY_TOPIC") or "").strip()
    if not topic:
        print("NTFY_TOPIC is not set. Add it as a repository secret (see README).")
        return 2
    server = (env.get("NTFY_SERVER") or "https://ntfy.sh").strip()
    ceb = (env.get("ALERT_LANGUAGE") or "").strip().lower().startswith("ceb")
    lang = "ceb" if ceb else "en"
    try:
        min_level = max(1, min(4, int((env.get("MIN_LEVEL") or "3").strip())))
    except ValueError:
        min_level = 3
    places = parse_places(env.get("PLACES") or DEFAULT_PLACES)
    if not places:
        print("No places to check. Fix the PLACES secret.")
        return 2
    dry = (env.get("DRY_RUN") or "").lower() in ("1", "true", "yes")

    def out(title, msg, level, tags):
        if dry:
            print("[dry run] %s | %s" % (title, msg))
        else:
            send(server, topic, title, msg, level, tags)

    if (env.get("TEST") or "").lower() == "true":
        out("Andam test" if not ceb else "Pagsulay sa Andam", "Your phone will get warnings like this one." if not ceb else "Ingon niini ang pasidaan nga madawat sa imong telepono.", 3, ["white_check_mark"])
        print("Test message sent.")
        return 0

    state = load_state(env.get("STATE_FILE") or STATE_FILE)
    sent = state.get("sent", {})
    sent = {k: v for k, v in sent.items() if now - v < 4 * 86400}  # forget old ones
    all_failed = True
    count = 0
    for p in places:
        print("Checking", p["name"])
        items, failed = checker(p["lat"], p["lng"], now)
        if len(failed) < 3:
            all_failed = False
        for it in items:
            if it["lvl"] < min_level:
                continue
            key = "%s|%s|%d" % (p["name"], it["id"], it["lvl"])
            if key in sent:
                continue
            t, b = text(it, ceb)
            title = "%s: %s (%s)" % (LEVELS[lang][it["lvl"]], t, p["name"])
            try:
                out(title, b, it["lvl"], ["rotating_light" if it["lvl"] >= 4 else "warning"])
                sent[key] = now
                count += 1
                print("  sent:", title)
            except Exception as e:
                print("  could not send (will try again next hour):", e)
    # a quiet "still running" message on Sundays, so you notice if GitHub ever switches the checker off
    today = time.strftime("%Y-%m-%d", time.gmtime(now + 8 * 3600))  # Philippine date
    if (env.get("HEARTBEAT") or "on").lower() != "off" and time.gmtime(now + 8 * 3600).tm_wday == 6 and state.get("beat") != today:
        try:
            out("Andam alerts are running" if not ceb else "Naglihok ang Andam alerts", "Checked every hour. Nothing else to do." if not ceb else "Gisusi matag oras. Wala nay lain nga buhaton.", 1, ["green_circle"])
            state["beat"] = today
        except Exception as e:
            print("  could not send the weekly check:", e)
    state["sent"] = sent
    if not dry:
        save_state(env.get("STATE_FILE") or STATE_FILE, state)
    print("Done. %d new message(s)." % count + (" Every service failed this time." if all_failed else ""))
    return 0


if __name__ == "__main__":
    sys.exit(run())
